#!/usr/bin/env python3
"""
queue_cmd.py — MyFluidData command queuer (Python 3)
Ported from Python 2 original.

Changes from Python 2:
- print statement -> print()
- os.chmod(path, 0777) -> os.chmod(path, 0o777)  (octal literal syntax)
- getopt unchanged — works in Python 3
"""

import getopt
import os
import sys
import time
import mfd


def queue(gauge, command, now=False):
    mfd.ensure_dir(mfd.data_dir())
    mfd.ensure_dir(mfd.cmd_queue_dir())

    stamp = '0000000000'
    if not now:
        stamp = str(int(time.time()))

    queue_filename = mfd.cmd_queue_dir() + '/' + stamp + '_' + gauge + '_' + command + '.sh'
    with open(queue_filename, "w") as fp:
        fp.write("#!/bin/bash\n")
        fp.write("ts=$(date '+%s') && ./kermit-scripts/serial.ksc {0} {1} $ts {2} {3} && cat ./data_files/$ts.{1}.dat\n".format(
            gauge, command, mfd.serial_port(), mfd.baud_rate()))

    # Fixed: 0777 -> 0o777 (Python 3 octal literal syntax)
    os.chmod(queue_filename, 0o777)
    mfd.log("Queued Command {0} for {1} {2}".format(command, gauge, stamp))


def help_text():
    print('queue_cmd.py -g <gauge> -c <command>')
    print('    -j , jump the queue')


def main(argv):
    now     = False
    command = False
    gauge   = False

    try:
        opts, args = getopt.getopt(argv, "hg:c:j")
    except getopt.GetoptError:
        help_text()
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-h':
            help_text()
            sys.exit()
        elif opt in ("-g", "--gauge"):
            gauge = arg
        elif opt in ("-c", "--command"):
            command = arg
        elif opt in ("-j", "--jump"):
            now = True

    if (command is False) or (gauge is False):
        print("Missing command to execute")
        help_text()
        sys.exit(1)

    queue(gauge, command, now)
    sys.exit(0)


print('Argument List:', str(sys.argv))

if __name__ == "__main__":
    main(sys.argv[1:])
