#!/bin/bash
ts=$(date '+%s') && ./kermit-scripts/serial.ksc auto-stick 100 $ts /dev/ttyS0 2400 && cat ./data_files/$ts.100.dat
