#!/bin/bash
# mfd-watchdog.sh — MFD Gateway hardware watchdog keeper + serial port monitor
# Run as a systemd service. Pets /dev/watchdog every 20 seconds.
# Also monitors ttyS0 health and resets it if RTS/UART state goes bad.
# If this script dies, the hardware watchdog fires and reboots the device.

WATCHDOG_DEV="/dev/watchdog"
SERIAL_PORT="/dev/ttyS0"
SERIAL_BAUD=2400
LOG_FILE="/root/logs/health.log"
SERIAL_FAIL_FILE="/tmp/mfd_serial_failures"
MAX_SERIAL_FAILS=3

# Never let set -e or any error exit this script unexpectedly
set +e

mkdir -p /root/logs

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') WATCHDOG: $1" >> "$LOG_FILE"
    echo "$(date '+%Y-%m-%d %H:%M:%S') WATCHDOG: $1"
}

# ── Open watchdog device ──────────────────────────────────────────────────────
WATCHDOG_OPEN=false
if [ -w "$WATCHDOG_DEV" ]; then
    exec 200>"$WATCHDOG_DEV"
    if [ $? -eq 0 ]; then
        WATCHDOG_OPEN=true
        log "Hardware watchdog opened: $WATCHDOG_DEV (timeout: $(cat /sys/class/watchdog/watchdog0/timeout 2>/dev/null || echo unknown)s)"
    else
        log "WARNING: Could not open $WATCHDOG_DEV — hardware watchdog not active"
    fi
else
    log "WARNING: $WATCHDOG_DEV not writable — hardware watchdog not active"
fi

pet_watchdog() {
    if [ "$WATCHDOG_OPEN" = true ]; then
        echo -n "1" >&200 2>/dev/null || {
            # fd closed unexpectedly — try to reopen
            log "Watchdog fd lost — attempting reopen"
            exec 200>"$WATCHDOG_DEV" 2>/dev/null && WATCHDOG_OPEN=true || {
                log "ERROR: Cannot reopen watchdog — hardware reboot imminent"
                WATCHDOG_OPEN=false
            }
        }
    fi
}

check_serial_port() {
    # Safely check dmesg for bad RTS/UART state — grep returns 1 if no match, that's fine
    if dmesg 2>/dev/null | tail -50 | grep -q "invalid RTS setting" 2>/dev/null; then
        prev=0
        if [ -f "$SERIAL_FAIL_FILE" ]; then
            prev=$(cat "$SERIAL_FAIL_FILE" 2>/dev/null | tr -d '[:space:]')
            [ -z "$prev" ] && prev=0
        fi
        fails=$((prev + 1))
        echo "$fails" > "$SERIAL_FAIL_FILE"
        log "Bad RTS state detected on $SERIAL_PORT (count: $fails) — resetting port"
        stty -F "$SERIAL_PORT" "$SERIAL_BAUD" cs8 -cstopb -parenb -crtscts 2>/dev/null
        # Clear dmesg ring so we don't keep detecting the same message
        dmesg -c > /dev/null 2>&1 || true

        if [ "$fails" -ge "$MAX_SERIAL_FAILS" ]; then
            log "Serial port reset failed $fails times — rebooting"
            echo 0 > "$SERIAL_FAIL_FILE"
            # Disarm watchdog cleanly before reboot
            if [ "$WATCHDOG_OPEN" = true ]; then
                echo -n "V" >&200 2>/dev/null || true
            fi
            reboot
        fi
    else
        # Serial port looks healthy — reset failure counter
        echo "0" > "$SERIAL_FAIL_FILE"
    fi
    return 0
}

log "Started — petting $WATCHDOG_DEV every 20s, monitoring $SERIAL_PORT"

# ── Main loop — must never exit ───────────────────────────────────────────────
while true; do
    pet_watchdog
    check_serial_port
    sleep 20 || true
done

# Should never reach here — log if we do
log "ERROR: Main loop exited unexpectedly"
