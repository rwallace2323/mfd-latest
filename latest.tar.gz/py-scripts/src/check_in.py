#!/usr/bin/env python3
"""
check_in.py — MyFluidData gateway check-in (Python 3)
Ported from Python 2 original.

Changes from Python 2:
- ConfigParser -> configparser
- json.loads on res.read() — read() now returns bytes, decode first
- open(path, 'wb') -> open(path, 'w') for config writes
- print statement -> print()
- Fixed: `!= 200 or != 302` -> `!= 200 and != 302` (original bug retained for compatibility)
- Process lock added to prevent duplicate cron instances
- Heartbeat file written after successful check-in for health_check.sh
"""

import configparser
import json
import os
import sys
import fcntl
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mfd

log_scope = 'CHECK-IN'
LOCK_FILE      = '/tmp/mfd_checkin.lock'
HEARTBEAT_FILE = '/tmp/last_checkin_timestamp'


def acquire_lock():
    """Prevent duplicate instances from cron overlap."""
    lock_fd = open(LOCK_FILE, 'w')
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError:
        mfd.log('check_in.py already running — exiting', log_scope)
        sys.exit(0)
    return lock_fd


def write_heartbeat():
    """Write timestamp for health_check.sh to monitor."""
    try:
        with open(HEARTBEAT_FILE, 'w') as f:
            f.write(str(int(time.time())))
    except Exception as e:
        mfd.log("Warning: Could not write heartbeat: " + str(e), log_scope)


def setup():
    """First-run: get a gateway_hash from server and write gateway.conf."""
    setup_conn = mfd.http_post('Gateways/init.json')
    setup_res = setup_conn.getresponse()
    if setup_res.status != 200:
        mfd.log(setup_res.read().decode('utf-8'), log_scope)
        sys.exit(1)

    res_data = json.loads(setup_res.read().decode('utf-8'))
    setup_conn.close()

    new_config = configparser.RawConfigParser()
    new_config.add_section('Gateway')
    new_config.set('Gateway', 'location_hash', 'unknown')
    new_config.set('Gateway', 'gateway_hash', res_data['gateway_hash'])
    with open(mfd.get_gateway_config_file_path(), 'w') as config_file:
        new_config.write(config_file)


def claim_me(config):
    """Unclaimed gateway: poll server until someone assigns it a location."""
    gateway_hash = config.get('Gateway', 'gateway_hash')
    claim_me_conn = mfd.http_post('Gateways/claim_me.json', 'gateway_hash=' + gateway_hash)
    claim_me_res = claim_me_conn.getresponse()
    if claim_me_res.status != 200:
        mfd.log(claim_me_res.read().decode('utf-8'), log_scope)
        sys.exit(1)

    res_data = json.loads(claim_me_res.read().decode('utf-8'))
    if not res_data['claimed']:
        sys.exit(0)

    claim_me_conn.close()

    config.set('Gateway', 'location_hash', res_data['location_hash'])
    with open(mfd.get_gateway_config_file_path(), 'w') as config_file:
        config.write(config_file)


def check_live(config):
    """Handle first-run and unclaimed states before normal check-in."""
    if not config:
        mfd.log("Hey! I'm a new gateway.", log_scope)
        setup()
        sys.exit(0)
    if config.get('Gateway', 'location_hash') == 'unknown':
        mfd.log("Hey! Someone please claim me. Please!", log_scope)
        claim_me(config)
        sys.exit(0)


# ── Main ──────────────────────────────────────────────────────────────────────

lock_fd = acquire_lock()

mfd.log("------------------------------------------------", log_scope)
mfd.log("- Checking In", log_scope)
mfd.log("------------------------------------------------", log_scope)

mfd.random_delay()

gateway_config = mfd.open_gateway_config_file()
check_live(gateway_config)

mfd_config = mfd.open_mfd_config_file()

post_data = (
    mfd.gateway_post_data(gateway_config)
    + "&version=" + mfd_config.get("MyFluidData", "version")
    + "&vpn_ip_address=" + mfd.get_vpn_ip()
)

conn_post = mfd.http_post("Gateways/check_in.json", post_data)
res = conn_post.getresponse()
response_body = res.read().decode('utf-8')

mfd.log("HTTP Response: status={0} reason={1}".format(res.status, res.reason), log_scope)

if res.status == 200 or res.status == 302:
    write_heartbeat()
    try:
        res_data = json.loads(response_body)
        if res_data.get('do'):
            mfd.log("Executing: " + res_data['do'], log_scope)
            os.system(res_data['do'])
    except Exception as e:
        mfd.log("Could not parse response: " + str(e), log_scope)
else:
    mfd.log("Check-in failed: " + response_body, log_scope)

conn_post.close()

mfd.log("------------------------------------------------", log_scope)
mfd.log("- End Checking In", log_scope)
mfd.log("------------------------------------------------", log_scope)
