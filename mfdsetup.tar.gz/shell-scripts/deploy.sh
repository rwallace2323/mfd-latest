#!/bin/bash
# =============================================================================
# MFD Gateway — Deployment Bootstrapper
# Usage: curl -fsSL http://myfluiddata.com/files/deploy.sh | bash
#        -- OR --
#        bash deploy.sh
# =============================================================================
set -e

# ── Config ────────────────────────────────────────────────────────────────────
FILES_URL="https://raw.githubusercontent.com/rwallace2323/mfd-latest/main/mfddeploy.tar.gz"
INSTALL_DIR="/root"
LOG_FILE="/var/log/mfd-deploy.log"
SERVICE_DIR="/etc/systemd/system"
UNIT_HOSTNAME=""      # or pass as env: UNIT_HOSTNAME=mfd-site01 bash deploy.sh

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m'

# ── Logging ───────────────────────────────────────────────────────────────────
exec > >(tee -a "$LOG_FILE") 2>&1

log()     { echo -e "${WHITE}[$(date '+%H:%M:%S')] $1${NC}"; }
ok()      { echo -e "${GREEN}  OK   $1${NC}"; }
warn()    { echo -e "${YELLOW}  WARN $1${NC}"; }
fail()    { echo -e "${RED}  FAIL $1${NC}"; exit 1; }
section() {
  echo ""
  echo -e "${CYAN}${BOLD}========================================${NC}"
  echo -e "${CYAN}${BOLD}  $1${NC}"
  echo -e "${CYAN}${BOLD}========================================${NC}"
}

# ── Banner ────────────────────────────────────────────────────────────────────
clear
echo ""
echo -e "${CYAN}${BOLD}  MFD Gateway -- Deployment Script${NC}"
echo -e "${WHITE}  BeagleBone Black / Linux${NC}"
echo -e "${WHITE}  Log: ${LOG_FILE}${NC}"
echo ""

# ── Root check ────────────────────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && fail "This script must be run as root. Try: sudo bash deploy.sh"

# ── Gather per-unit config ────────────────────────────────────────────────────
section "Unit Configuration"

if [[ -z "$UNIT_HOSTNAME" ]]; then
  read -rp "  Enter unit hostname (e.g. mfd-gateway-site01): " UNIT_HOSTNAME
fi
[[ -z "$UNIT_HOSTNAME" ]] && fail "Hostname cannot be empty."

log "Hostname : $UNIT_HOSTNAME"

# ── VPN selection ─────────────────────────────────────────────────────────────
section "VPN Setup"
echo "  Which VPN(s) do you want to install?"
echo "    1) ZeroTier only"
echo "    2) Tailscale only"
echo "    3) Both ZeroTier and Tailscale"
echo "    4) Skip VPN setup"
echo ""
read -rp "  Select [1-4]: " VPN_CHOICE

INSTALL_ZEROTIER=false
INSTALL_TAILSCALE=false
ZEROTIER_NETWORK=""
TAILSCALE_AUTHKEY=""

case "$VPN_CHOICE" in
  1) INSTALL_ZEROTIER=true ;;
  2) INSTALL_TAILSCALE=true ;;
  3) INSTALL_ZEROTIER=true; INSTALL_TAILSCALE=true ;;
  4) warn "VPN setup skipped" ;;
  *) warn "Invalid selection -- skipping VPN setup" ;;
esac

if $INSTALL_ZEROTIER; then
  read -rp "  ZeroTier Network ID (leave blank to install only, join later): " ZEROTIER_NETWORK
fi

if $INSTALL_TAILSCALE; then
  read -rp "  Tailscale Auth Key (leave blank to install only, auth later): " TAILSCALE_AUTHKEY
fi

# ── Set hostname ──────────────────────────────────────────────────────────────
section "System -- Hostname"
hostnamectl set-hostname "$UNIT_HOSTNAME"
if grep -q "127.0.1.1" /etc/hosts; then
  sed -i "s/^127\.0\.1\.1.*/127.0.1.1\t$UNIT_HOSTNAME/" /etc/hosts
else
  echo "127.0.1.1	$UNIT_HOSTNAME" >> /etc/hosts
fi
ok "Hostname set to: $UNIT_HOSTNAME"

# ── DNS fallback ──────────────────────────────────────────────────────────────
section "System -- DNS"
if ! grep -q "8.8.8.8" /etc/resolv.conf; then
  echo "nameserver 8.8.8.8" >> /etc/resolv.conf
  ok "Added Google DNS fallback (8.8.8.8)"
else
  ok "Google DNS already present"
fi

# ── Fix NetworkManager / systemd-networkd conflict ────────────────────────────
section "Network -- Fix systemd-networkd Conflict"
log "Disabling systemd-networkd to prevent dual-DHCP conflict with NetworkManager..."
systemctl stop systemd-networkd        2>/dev/null && ok "Stopped systemd-networkd"        || ok "systemd-networkd was not running"
systemctl disable systemd-networkd     2>/dev/null && ok "Disabled systemd-networkd"       || ok "systemd-networkd already disabled"
systemctl stop systemd-networkd.socket 2>/dev/null && ok "Stopped systemd-networkd.socket" || ok "systemd-networkd.socket was not running"
systemctl disable systemd-networkd.socket 2>/dev/null && ok "Disabled systemd-networkd.socket" || ok "systemd-networkd.socket already disabled"

# Install and enable NetworkManager as sole network manager
if ! dpkg -s network-manager &>/dev/null; then
  log "Installing NetworkManager..."
  apt-get install -y -q network-manager && ok "NetworkManager installed" || warn "NetworkManager install failed"
else
  ok "NetworkManager already installed"
fi
systemctl enable NetworkManager 2>/dev/null && ok "NetworkManager enabled" || warn "Could not enable NetworkManager"
systemctl start NetworkManager  2>/dev/null && ok "NetworkManager started" || warn "Could not start NetworkManager"

# ── Package install ───────────────────────────────────────────────────────────
section "Packages"
log "Running apt-get update..."
apt-get update -y -q

PACKAGES=(ckermit python3 python3-serial curl)
for pkg in "${PACKAGES[@]}"; do
  if dpkg -s "$pkg" &>/dev/null; then
    ok "$pkg already installed"
  else
    log "Installing $pkg..."
    apt-get install -y -q "$pkg" && ok "$pkg installed" || warn "$pkg install failed -- continuing"
  fi
done

# ── Serial port — free ttyS0 ─────────────────────────────────────────────────
section "Serial Port -- Free /dev/ttyS0"

UENV="/boot/uEnv.txt"
if [[ -f "$UENV" ]]; then
  if grep -q "console=ttyS0" "$UENV" || grep -q "console=ttyO0" "$UENV"; then
    cp "$UENV" "${UENV}.bak.$(date +%Y%m%d%H%M%S)"
    sed -i 's/console=ttyS0,[^ ]*//g' "$UENV"
    sed -i 's/console=ttyO0,[^ ]*//g' "$UENV"
    ok "Removed console=ttyS0/ttyO0 from $UENV (backup saved)"
  else
    ok "No console=ttyS0 found in $UENV -- nothing to remove"
  fi
else
  warn "$UENV not found -- skipping (may not be a BBB)"
fi

for TTY in ttyS0 ttyO0; do
  systemctl mask "serial-getty@${TTY}.service" 2>/dev/null \
    && ok "Masked serial-getty@${TTY}.service" \
    || warn "Could not mask serial-getty@${TTY}.service"
  systemctl stop "serial-getty@${TTY}.service" 2>/dev/null || true
done

# ── ZeroTier ──────────────────────────────────────────────────────────────────
if $INSTALL_ZEROTIER; then
  section "ZeroTier VPN"
  if command -v zerotier-cli &>/dev/null; then
    ok "ZeroTier already installed"
  else
    log "Installing ZeroTier..."
    curl -fsSL https://install.zerotier.com | bash \
      && ok "ZeroTier installed" \
      || fail "ZeroTier install failed -- check internet connectivity"
  fi

  systemctl enable zerotier-one
  systemctl start zerotier-one
  sleep 3

  if [[ -n "$ZEROTIER_NETWORK" ]]; then
    log "Joining ZeroTier network: $ZEROTIER_NETWORK"
    zerotier-cli join "$ZEROTIER_NETWORK" \
      && ok "Joined ZeroTier network $ZEROTIER_NETWORK" \
      || warn "zerotier-cli join returned an error -- run manually: zerotier-cli join $ZEROTIER_NETWORK"
    echo ""
    warn "ACTION REQUIRED: Authorize this device in your ZeroTier controller:"
    echo -e "${WHITE}    Node ID  : $(zerotier-cli info | awk '{print $3}')${NC}"
    echo -e "${WHITE}    Network  : ${ZEROTIER_NETWORK}${NC}"
    echo -e "${WHITE}    Hostname : ${UNIT_HOSTNAME}${NC}"
  else
    warn "ZeroTier installed -- no network ID given. Join later: zerotier-cli join <network-id>"
    echo -e "${WHITE}    Node ID  : $(zerotier-cli info | awk '{print $3}')${NC}"
  fi
fi

# ── Tailscale ─────────────────────────────────────────────────────────────────
if $INSTALL_TAILSCALE; then
  section "Tailscale VPN"
  if command -v tailscale &>/dev/null; then
    ok "Tailscale already installed"
  else
    log "Installing Tailscale..."
    curl -fsSL https://tailscale.com/install.sh | bash \
      && ok "Tailscale installed" \
      || fail "Tailscale install failed -- check internet connectivity"
  fi

  systemctl enable tailscaled
  systemctl start tailscaled
  sleep 3

  if [[ -n "$TAILSCALE_AUTHKEY" ]]; then
    log "Authenticating Tailscale..."
    tailscale up --authkey "$TAILSCALE_AUTHKEY" --hostname "$UNIT_HOSTNAME" \
      && ok "Tailscale connected as $UNIT_HOSTNAME" \
      || warn "Tailscale auth failed -- run manually: tailscale up --authkey <key>"
  else
    warn "Tailscale installed -- no auth key given. Authenticate later: tailscale up"
  fi
fi


# ── DNS Setup ─────────────────────────────────────────────────────────────────
section "DNS -- systemd-resolved + NetworkManager"

# Enable systemd-resolved if not running
systemctl is-active --quiet systemd-resolved || systemctl enable --now systemd-resolved
ok "systemd-resolved active"

# Point resolv.conf to stub resolver
ln -sf /run/systemd/resolve/stub-resolv.conf /etc/resolv.conf
ok "resolv.conf -> stub resolver (127.0.0.53)"

# Configure systemd-resolved with fallback DNS
cat > /etc/systemd/resolved.conf << 'DNSEOF'
[Resolve]
DNS=
FallbackDNS=1.1.1.1 9.9.9.9 8.8.8.8
DNSSEC=allow-downgrade
DNSOverTLS=no
Cache=yes
MulticastDNS=no
DNSEOF
ok "systemd-resolved configured (fallback: 1.1.1.1, 9.9.9.9, 8.8.8.8)"

# Configure NetworkManager to hand DNS to systemd-resolved
mkdir -p /etc/NetworkManager/conf.d
cat > /etc/NetworkManager/conf.d/dns.conf << 'DNSEOF'
[main]
dns=systemd-resolved
systemd-resolved=true
DNSEOF

cat > /etc/NetworkManager/conf.d/dhcp.conf << 'DNSEOF'
[main]
dhcp=internal

[connection]
ipv4.dns-priority=-100
DNSEOF
ok "NetworkManager DNS integration configured"

# Keep ZeroTier interfaces out of systemd-networkd (prevent conflicts)
mkdir -p /etc/systemd/network
cat > /etc/systemd/network/99-zerotier.network << 'DNSEOF'
[Match]
Name=zt*

[Network]
DHCP=no
IgnoreCarrierLoss=yes
DNSEOF
ok "ZeroTier interface isolation configured"

# ZeroTier local settings if installed
if [[ -d /var/lib/zerotier-one && ! -f /var/lib/zerotier-one/local.conf ]]; then
  cat > /var/lib/zerotier-one/local.conf << 'DNSEOF'
{
  "settings": {
    "allowManagementFrom": ["127.0.0.1/8"],
    "softwareUpdate": "disable"
  }
}
DNSEOF
  ok "ZeroTier local.conf created"
fi

# Restart both services to apply
systemctl restart systemd-resolved
systemctl restart NetworkManager
sleep 2
ok "DNS services restarted"

# Quick verify
if resolvectl query google.com > /dev/null 2>&1; then
  ok "DNS resolution working (google.com resolved)"
else
  warn "DNS resolution test failed -- may be a network issue, verify after reboot"
fi

# ── Download & extract gateway files ─────────────────────────────────────────
section "Gateway Files"
log "Downloading $FILES_URL ..."
cd "$INSTALL_DIR"
curl -fSL "$FILES_URL" -o mfddeploy.tar.gz \
  && ok "Download complete" \
  || fail "Failed to download $FILES_URL -- check URL and connectivity"

tar -xf mfddeploy.tar.gz && ok "Extracted to $INSTALL_DIR" || fail "Extraction failed"

# ── Permissions ───────────────────────────────────────────────────────────────
section "Permissions"
mkdir -p "$INSTALL_DIR/data_files"
mkdir -p "$INSTALL_DIR/logs"
ok "data_files/ and logs/ directories ready"

find "$INSTALL_DIR/cron"          -name "*.cron" -exec chmod 644 {} \; 2>/dev/null && ok "cron/ files -> 644"               || true
find "$INSTALL_DIR/shell-scripts" -name "*.sh"   -exec chmod 700 {} \; 2>/dev/null && ok "shell-scripts/ .sh files -> 700"  || true
find "$INSTALL_DIR/py-scripts"    -name "*.py"   -exec chmod 755 {} \; 2>/dev/null && ok "py-scripts/ .py files -> 755"     || true
[[ -f "$INSTALL_DIR/kermit-scripts/serial.ksc" ]] && chmod 700 "$INSTALL_DIR/kermit-scripts/serial.ksc" && ok "kermit-scripts/serial.ksc -> 700" || true

# ── Systemd Services ──────────────────────────────────────────────────────────
section "Systemd Services"
MFD_SERVICES=(mfd-watchdog mfd-health)

for svc in "${MFD_SERVICES[@]}"; do
  systemctl stop "$svc"    2>/dev/null || true
  systemctl disable "$svc" 2>/dev/null || true
done

for svc in "${MFD_SERVICES[@]}"; do
  SRC="$INSTALL_DIR/systemd/${svc}.service"
  DST="$SERVICE_DIR/${svc}.service"
  if [[ -f "$SRC" ]]; then
    cp "$SRC" "$DST"
    chmod 644 "$DST"
    ok "Installed $svc.service"
  else
    warn "$svc.service not found in $INSTALL_DIR/systemd/ -- skipping"
  fi
done

[[ -f "$INSTALL_DIR/shell-scripts/mfd-watchdog.sh" ]] && chmod 700 "$INSTALL_DIR/shell-scripts/mfd-watchdog.sh" && ok "mfd-watchdog.sh -> 700" || true

systemctl daemon-reload
ok "systemd daemon reloaded"

for svc in "${MFD_SERVICES[@]}"; do
  if [[ -f "$SERVICE_DIR/${svc}.service" ]]; then
    systemctl enable "$svc" && ok "Enabled $svc" || warn "Could not enable $svc"
  fi
done
log "Services will start on next reboot"


# ── Login MOTD ────────────────────────────────────────────────────────────────
section "Login Screen"

cat > /etc/profile.d/mfd-motd.sh << 'MOTDEOF'
#!/bin/bash
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
RED='\033[1;31m'
NC='\033[0m'
BOLD='\033[1m'

VERSION=$(cat /root/version.txt 2>/dev/null || echo "unknown")
HOSTNAME=$(hostname)
UPTIME=$(uptime -p 2>/dev/null | sed 's/up //')
IP_ETH=$(ip -4 addr show eth0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
IP_WLAN=$(ip -4 addr show wlan0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
IP_ZT=$(ip -4 addr show 2>/dev/null | grep -A1 "zt" | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
IP_TS=$(ip -4 addr show tailscale0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
GAUGE=$(grep "^gauge_model" /root/gateway.conf 2>/dev/null | cut -d= -f2 | tr -d ' ')
LAST_DATA=$(ls -t /root/data_files/*.dat 2>/dev/null | head -1 | while read f; do stat -c '%y' "$f" 2>/dev/null | cut -d'.' -f1; done)
CRON_COUNT=$(crontab -l 2>/dev/null | grep -v "^#" | grep -v "^$" | wc -l)
SERIAL=$(systemctl is-enabled serial-getty@ttyS0.service 2>/dev/null)

echo ""
echo -e "${CYAN}${BOLD}  ╔══════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}${BOLD}  ║         MFD Gateway -- $(printf '%-20s' $HOSTNAME)  ║${NC}"
echo -e "${CYAN}${BOLD}  ╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${WHITE}  Gateway Files : ${GREEN}${VERSION}${NC}"
echo -e "${WHITE}  Uptime        : ${NC}${UPTIME}"
echo ""
echo -e "${WHITE}  Network${NC}"
echo -e "${WHITE}    eth0        : ${NC}${IP_ETH:-not connected}"
echo -e "${WHITE}    wlan0       : ${NC}${IP_WLAN:-not connected}"
echo -e "${WHITE}    ZeroTier    : ${NC}${IP_ZT:-not connected}"
echo -e "${WHITE}    Tailscale   : ${NC}${IP_TS:-not connected}"
echo ""
echo -e "${WHITE}  Gateway${NC}"
if [[ -n "$GAUGE" ]]; then
  echo -e "${WHITE}    Gauge Model : ${GREEN}${GAUGE}${NC}"
else
  echo -e "${WHITE}    Gauge Model : ${YELLOW}not detected yet${NC}"
fi
echo -e "${WHITE}    Cron Jobs   : ${NC}${CRON_COUNT} active"
if [[ -n "$LAST_DATA" ]]; then
  echo -e "${WHITE}    Last Data   : ${NC}${LAST_DATA}"
else
  echo -e "${WHITE}    Last Data   : ${YELLOW}no data files yet${NC}"
fi
echo ""
if [[ "$SERIAL" != "masked" ]]; then
  echo -e "${RED}  WARNING: serial-getty@ttyS0 is not masked (status: $SERIAL)${NC}"
  echo -e "${RED}           Run: systemctl mask serial-getty@ttyS0.service${NC}"
  echo ""
fi
echo -e "${WHITE}  Staging       : staging.myfluiddata.com${NC}"
echo -e "${WHITE}  Log           : /var/log/mfd-deploy.log${NC}"
echo ""
MOTDEOF

chmod +x /etc/profile.d/mfd-motd.sh
ok "Login MOTD installed -- will display on every SSH login"

# Clear the default Debian MOTD so it doesn't clutter above ours
> /etc/motd
ok "Cleared default /etc/motd"

# ── Crontab ───────────────────────────────────────────────────────────────────
section "Crontab"
CRON_DIR="$INSTALL_DIR/cron"
if [[ -f "$CRON_DIR/base.cron" && -f "$CRON_DIR/negotiate.cron" ]]; then
  cat "$CRON_DIR/base.cron" "$CRON_DIR/negotiate.cron" | crontab -
  ok "Installed base.cron + negotiate.cron"
  log "Active crontab:"
  crontab -l | sed 's/^/    /'
else
  warn "base.cron or negotiate.cron not found in $CRON_DIR -- skipping crontab install"
fi

# ── Version & Cleanup ─────────────────────────────────────────────────────────
if [[ -f "$INSTALL_DIR/version.txt" ]]; then
  DEPLOYED_VERSION=$(cat "$INSTALL_DIR/version.txt")
  ok "Gateway files version: $DEPLOYED_VERSION"
else
  warn "version.txt not found in package -- add it to track versions"
  DEPLOYED_VERSION="unknown"
fi
rm -f "$INSTALL_DIR/mfddeploy.tar.gz"
ok "Removed mfddeploy.tar.gz"

# ── Summary ───────────────────────────────────────────────────────────────────
section "Deployment Complete"
echo ""
echo -e "${GREEN}${BOLD}  SETUP SUCCESSFUL${NC}"
echo ""
echo -e "${WHITE}  Unit Hostname : ${CYAN}$UNIT_HOSTNAME${NC}"
echo -e "${WHITE}  ZeroTier      : ${CYAN}$( $INSTALL_ZEROTIER && echo "installed${ZEROTIER_NETWORK:+ — network $ZEROTIER_NETWORK}" || echo "skipped" )${NC}"
echo -e "${WHITE}  Tailscale     : ${CYAN}$( $INSTALL_TAILSCALE && echo "installed${TAILSCALE_AUTHKEY:+ — authenticated}" || echo "skipped" )${NC}"
echo -e "${WHITE}  Install Dir   : $INSTALL_DIR${NC}"
echo -e "${WHITE}  Log File      : $LOG_FILE${NC}"
echo -e "${WHITE}  Files Version : ${CYAN}${DEPLOYED_VERSION:-unknown}${NC}"
echo ""
echo -e "${YELLOW}  Next steps:${NC}"
echo "    1. Authorize this device in ZeroTier / Tailscale controller (if not done)"
echo "    2. Reboot now to apply all changes"
echo "    3. After reboot -- systemctl status serial-getty@ttyS0.service  (must show: masked)"
echo "    4. Verify network: ip addr  (should show single IP on each interface)"
echo "    5. Verify crontab: crontab -l"
echo "    6. Test negotiate: cd /root && python3 negotiate.py"
echo ""
read -rp "  Reboot now? [Y/n]: " DO_REBOOT
[[ "${DO_REBOOT,,}" != "n" ]] && shutdown -r now || echo "  Reboot skipped -- remember to reboot before use."
