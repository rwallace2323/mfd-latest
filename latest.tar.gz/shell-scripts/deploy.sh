#!/bin/bash
# =============================================================================
# MFD Gateway — Deployment Bootstrapper
# Usage: curl -fsSL http://myfluiddata.com/files/deploy.sh | bash
#        -- OR --
#        bash deploy.sh
# =============================================================================
set -e

# ── Config ────────────────────────────────────────────────────────────────────
FILES_URL="https://raw.githubusercontent.com/rwallace2323/mfd-latest/main/latest.tar.gz"
INSTALL_DIR="/root"
LOG_FILE="/var/log/mfd-deploy.log"
ZEROTIER_NETWORK=""   # Set here OR pass as env: ZEROTIER_NETWORK=abc123 bash deploy.sh
UNIT_HOSTNAME=""      # Set here OR pass as env: UNIT_HOSTNAME=mfd-site01 bash deploy.sh
SERVICE_DIR="/etc/systemd/system"

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m'

# ── Logging ───────────────────────────────────────────────────────────────────
exec > >(tee -a "$LOG_FILE") 2>&1

log()     { echo -e "${WHITE}[$(date '+%H:%M:%S')] $1${NC}"; }
ok()      { echo -e "${GREEN}  OK   $1${NC}"; }
warn()    { echo -e "${YELLOW}  WARN $1${NC}"; }
fail()    { echo -e "${RED}  FAIL $1${NC}"; exit 1; }
section() {
  echo ""
  echo -e "${CYAN}${BOLD}========================================${NC}"
  echo -e "${CYAN}${BOLD}  $1${NC}"
  echo -e "${CYAN}${BOLD}========================================${NC}"
}

# ── Banner ────────────────────────────────────────────────────────────────────
clear
echo ""
echo -e "${CYAN}${BOLD}  MFD Gateway -- Deployment Script${NC}"
echo -e "${WHITE}  BeagleBone Black / Linux${NC}"
echo -e "${WHITE}  Log: ${LOG_FILE}${NC}"
echo ""

# ── Root check ────────────────────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && fail "This script must be run as root. Try: sudo bash deploy.sh"

# ── Gather per-unit config ────────────────────────────────────────────────────
section "Unit Configuration"

if [[ -z "$UNIT_HOSTNAME" ]]; then
  read -rp "  Enter unit hostname (e.g. mfd-gateway-site01): " UNIT_HOSTNAME
fi
[[ -z "$UNIT_HOSTNAME" ]] && fail "Hostname cannot be empty."

if [[ -z "$ZEROTIER_NETWORK" ]]; then
  read -rp "  Enter ZeroTier Network ID (leave blank to skip): " ZEROTIER_NETWORK
fi

log "Hostname  : $UNIT_HOSTNAME"
log "ZeroTier  : ${ZEROTIER_NETWORK:-SKIPPED}"

# ── Set hostname ──────────────────────────────────────────────────────────────
section "System -- Hostname"
hostnamectl set-hostname "$UNIT_HOSTNAME"
if grep -q "127.0.1.1" /etc/hosts; then
  sed -i "s/^127\.0\.1\.1.*/127.0.1.1\t$UNIT_HOSTNAME/" /etc/hosts
else
  echo "127.0.1.1	$UNIT_HOSTNAME" >> /etc/hosts
fi
ok "Hostname set to: $UNIT_HOSTNAME"

# ── DNS fallback ──────────────────────────────────────────────────────────────
section "System -- DNS"
if ! grep -q "8.8.8.8" /etc/resolv.conf; then
  echo "nameserver 8.8.8.8" >> /etc/resolv.conf
  ok "Added Google DNS fallback (8.8.8.8)"
else
  ok "Google DNS already present"
fi

# ── Package install ───────────────────────────────────────────────────────────
section "Packages"
log "Running apt-get update..."
apt-get update -y -q

PACKAGES=(ckermit python3 python3-serial curl)
for pkg in "${PACKAGES[@]}"; do
  if dpkg -s "$pkg" &>/dev/null; then
    ok "$pkg already installed"
  else
    log "Installing $pkg..."
    apt-get install -y -q "$pkg" && ok "$pkg installed" || warn "$pkg install failed -- continuing"
  fi
done

# ── Serial port — free ttyS0 ─────────────────────────────────────────────────
section "Serial Port -- Free /dev/ttyS0"

UENV="/boot/uEnv.txt"
if [[ -f "$UENV" ]]; then
  if grep -q "console=ttyS0" "$UENV" || grep -q "console=ttyO0" "$UENV"; then
    cp "$UENV" "${UENV}.bak.$(date +%Y%m%d%H%M%S)"
    sed -i 's/console=ttyS0,[^ ]*//g' "$UENV"
    sed -i 's/console=ttyO0,[^ ]*//g' "$UENV"
    ok "Removed console=ttyS0/ttyO0 from $UENV (backup saved)"
  else
    ok "No console=ttyS0 found in $UENV -- nothing to remove"
  fi
else
  warn "$UENV not found -- skipping (may not be a BBB)"
fi

for TTY in ttyS0 ttyO0; do
  systemctl mask "serial-getty@${TTY}.service" 2>/dev/null \
    && ok "Masked serial-getty@${TTY}.service" \
    || warn "Could not mask serial-getty@${TTY}.service"
  systemctl stop "serial-getty@${TTY}.service" 2>/dev/null || true
done

# ── ZeroTier ──────────────────────────────────────────────────────────────────
section "ZeroTier VPN"
if [[ -n "$ZEROTIER_NETWORK" ]]; then
  if command -v zerotier-cli &>/dev/null; then
    ok "ZeroTier already installed"
  else
    log "Installing ZeroTier..."
    curl -fsSL https://install.zerotier.com | bash \
      && ok "ZeroTier installed" \
      || fail "ZeroTier install failed -- check internet connectivity"
  fi

  systemctl enable zerotier-one
  systemctl start zerotier-one
  sleep 3

  log "Joining network: $ZEROTIER_NETWORK"
  zerotier-cli join "$ZEROTIER_NETWORK" \
    && ok "Joined ZeroTier network $ZEROTIER_NETWORK" \
    || warn "zerotier-cli join returned an error -- check manually: zerotier-cli status"

  echo ""
  warn "ACTION REQUIRED: Authorize this device in your ZeroTier controller:"
  echo -e "${WHITE}    Node ID  : $(zerotier-cli info | awk '{print $3}')${NC}"
  echo -e "${WHITE}    Network  : ${ZEROTIER_NETWORK}${NC}"
  echo -e "${WHITE}    Hostname : ${UNIT_HOSTNAME}${NC}"
else
  warn "ZeroTier skipped -- no network ID provided. Run later: zerotier-cli join <network-id>"
fi

# ── Download & extract gateway files ─────────────────────────────────────────
section "Gateway Files"
log "Downloading $FILES_URL ..."
cd "$INSTALL_DIR"
curl -fSL "$FILES_URL" -o latest.tar.gz \
  && ok "Download complete" \
  || fail "Failed to download $FILES_URL -- check URL and connectivity"

tar -xf latest.tar.gz && ok "Extracted to $INSTALL_DIR" || fail "Extraction failed"

if [[ -f "./upgrade.sh" ]]; then
  chmod +x ./upgrade.sh
  log "Running upgrade.sh..."
  ./upgrade.sh && ok "upgrade.sh completed" || warn "upgrade.sh exited with errors -- review log"
fi

# ── Permissions ───────────────────────────────────────────────────────────────
section "Permissions"
mkdir -p "$INSTALL_DIR/data_files"
mkdir -p "$INSTALL_DIR/logs"
ok "data_files/ and logs/ directories ready"

find "$INSTALL_DIR/cron"          -name "*.cron" -exec chmod 644 {} \; 2>/dev/null && ok "cron/ files -> 644" || true
find "$INSTALL_DIR/shell-scripts" -name "*.sh"   -exec chmod 700 {} \; 2>/dev/null && ok "shell-scripts/ .sh files -> 700" || true
find "$INSTALL_DIR/py-scripts"    -name "*.py"   -exec chmod 755 {} \; 2>/dev/null && ok "py-scripts/ .py files -> 755" || true
[[ -f "$INSTALL_DIR/kermit-scripts/serial.ksc" ]] && chmod 700 "$INSTALL_DIR/kermit-scripts/serial.ksc" && ok "kermit-scripts/serial.ksc -> 700" || true

# ── Systemd Services ──────────────────────────────────────────────────────────
section "Systemd Services"

MFD_SERVICES=(mfd-watchdog mfd-health)

# Stop and disable any existing MFD services first
for svc in "${MFD_SERVICES[@]}"; do
  systemctl stop "$svc" 2>/dev/null || true
  systemctl disable "$svc" 2>/dev/null || true
done

# Install service files
for svc in "${MFD_SERVICES[@]}"; do
  SRC="$INSTALL_DIR/systemd/${svc}.service"
  DST="$SERVICE_DIR/${svc}.service"
  if [[ -f "$SRC" ]]; then
    cp "$SRC" "$DST"
    chmod 644 "$DST"
    ok "Installed $svc.service"
  else
    warn "$svc.service not found in $INSTALL_DIR/systemd/ -- skipping"
  fi
done

# Install watchdog shell script
if [[ -f "$INSTALL_DIR/shell-scripts/mfd-watchdog.sh" ]]; then
  chmod 700 "$INSTALL_DIR/shell-scripts/mfd-watchdog.sh"
  ok "mfd-watchdog.sh -> 700"
fi

# Reload systemd and enable all services
systemctl daemon-reload
ok "systemd daemon reloaded"

for svc in "${MFD_SERVICES[@]}"; do
  if [[ -f "$SERVICE_DIR/${svc}.service" ]]; then
    systemctl enable "$svc" && ok "Enabled $svc" || warn "Could not enable $svc"
  fi
done

log "Services will start on next reboot"

# ── Crontab ───────────────────────────────────────────────────────────────────
section "Crontab"
CRON_DIR="$INSTALL_DIR/cron"
if [[ -f "$CRON_DIR/base.cron" && -f "$CRON_DIR/negotiate.cron" ]]; then
  # base.cron + negotiate.cron — gauge cron added by negotiate.py after ATG detection
  cat "$CRON_DIR/base.cron" "$CRON_DIR/negotiate.cron" | crontab -
  ok "Installed base.cron + negotiate.cron"
  log "Active crontab:"
  crontab -l | sed 's/^/    /'
else
  warn "base.cron not found in $CRON_DIR -- skipping crontab install"
fi

# ── Cleanup ───────────────────────────────────────────────────────────────────
rm -f "$INSTALL_DIR/latest.tar.gz"

# ── Summary ───────────────────────────────────────────────────────────────────
section "Deployment Complete"
echo ""
echo -e "${GREEN}${BOLD}  SETUP SUCCESSFUL${NC}"
echo ""
echo -e "${WHITE}  Unit Hostname : ${CYAN}$UNIT_HOSTNAME${NC}"
echo -e "${WHITE}  ZeroTier Net  : ${CYAN}${ZEROTIER_NETWORK:-not configured}${NC}"
echo -e "${WHITE}  Install Dir   : $INSTALL_DIR${NC}"
echo -e "${WHITE}  Log File      : $LOG_FILE${NC}"
echo ""
echo -e "${YELLOW}  Services installed (start on reboot):${NC}"
for svc in "${MFD_SERVICES[@]}"; do
  echo "    - $svc"
done
echo ""
echo -e "${YELLOW}  Cron jobs (check_in, executor, negotiate, uploader):${NC}"
echo "    crontab -l"
echo ""
echo -e "${YELLOW}  Next steps:${NC}"
echo "    1. Authorize this device in ZeroTier controller (if not done)"
echo "    2. Reboot now to apply all changes"
echo "    3. After reboot, verify services:"
echo "       systemctl status mfd-watchdog mfd-checkin mfd-executor mfd-negotiate mfd-health"
echo "    4. Verify crontab: crontab -l"
echo ""
read -rp "  Reboot now? [Y/n]: " DO_REBOOT
[[ "${DO_REBOOT,,}" != "n" ]] && shutdown -r now || echo "  Reboot skipped -- remember to reboot before use."
