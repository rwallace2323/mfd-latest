#!/usr/bin/env python3
"""
executor.py — MyFluidData command executor (Python 3)
Ported from Python 2 original with freeze fixes applied.

FREEZE FIXES:
- Process lock via fcntl — prevents duplicate cron instances piling up
- os.system() replaced with subprocess.Popen() + manual poll loop with 60s timeout
  (os.system() had no timeout — a hung kermit script blocked forever)
- Counts consecutive serial failures — clears gauge_model after 5 to trigger auto-renegotiation
- All exceptions caught so one bad command doesn't kill the whole run
"""

import fcntl
import os
import subprocess
import sys
import time
import mfd

log_scope = 'EXECUTOR'
COMMAND_TIMEOUT     = 60    # seconds before killing a hung kermit script
MAX_FAILURES        = 5     # consecutive failures before triggering renegotiation
FAILURE_COUNT_FILE  = '/tmp/mfd_executor_failures'

# ── Process lock ──────────────────────────────────────────────────────────────
# Prevents duplicate instances when cron fires while a previous run is still
# executing a serial command. Without this, hung instances pile up and freeze.
_lock_fp = open('/tmp/executor.lock', 'w')
try:
    fcntl.lockf(_lock_fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
except IOError:
    mfd.log("executor.py already running — exiting", log_scope)
    sys.exit(0)

# ── Main ──────────────────────────────────────────────────────────────────────

mfd.log("------------------------------------------------", log_scope)
mfd.log("- Executing Commands in cmd_queue", log_scope)
mfd.log("------------------------------------------------", log_scope)

mfd.ensure_dir(mfd.cmd_queue_dir())
commands = sorted(os.listdir(mfd.cmd_queue_dir()))

# Load consecutive failure count
try:
    with open(FAILURE_COUNT_FILE, 'r') as f:
        consecutive_failures = int(f.read().strip())
except Exception:
    consecutive_failures = 0

any_success = False

for c in commands:
    cmd_path = mfd.cmd_queue_dir() + '/' + c
    mfd.log("Executing " + cmd_path, log_scope)

    try:
        # subprocess.Popen with manual poll — os.system() had no timeout
        proc = subprocess.Popen(['/bin/bash', cmd_path],
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 cwd='/root')
        deadline = time.time() + COMMAND_TIMEOUT
        while time.time() < deadline:
            if proc.poll() is not None:
                break
            time.sleep(1)
        else:
            proc.kill()
            mfd.log("Command timed out after {0}s, killed: {1}".format(COMMAND_TIMEOUT, cmd_path), log_scope)
            continue

        stdout, stderr = proc.communicate()
        if stdout:
            mfd.log("Response:\n" + stdout.decode('utf-8', errors='replace'), log_scope)
        if stderr:
            mfd.log("stderr: " + stderr.decode('utf-8', errors='replace'), log_scope)
        if proc.returncode != 0:
            mfd.log("Command exited {0}: {1}".format(proc.returncode, cmd_path), log_scope)

        any_success = True

    except Exception as e:
        mfd.log("Command failed {0}: {1}".format(cmd_path, str(e)), log_scope)

    finally:
        try:
            os.remove(cmd_path)
        except Exception:
            pass

# Track consecutive failures for auto-renegotiation
if any_success:
    consecutive_failures = 0
else:
    consecutive_failures += 1
    mfd.log("Consecutive failures: {0}".format(consecutive_failures), log_scope)

with open(FAILURE_COUNT_FILE, 'w') as f:
    f.write(str(consecutive_failures))

# After MAX_FAILURES consecutive failures, clear gauge_model so neg.py re-negotiates
if consecutive_failures >= MAX_FAILURES:
    mfd.log("Too many failures — clearing gauge_model for auto-renegotiation", log_scope)
    config = mfd.open_gateway_config_file()
    if config and config.has_option('Gateway', 'gauge_model'):
        config.remove_option('Gateway', 'gauge_model')
        with open(mfd.get_gateway_config_file_path(), 'w') as cf:
            config.write(cf)
    with open(FAILURE_COUNT_FILE, 'w') as f:
        f.write('0')

mfd.log("------------------------------------------------", log_scope)
mfd.log("- Finished Executing Commands", log_scope)
mfd.log("------------------------------------------------", log_scope)
