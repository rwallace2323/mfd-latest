#!/usr/bin/env python3
"""
mfd.py — MyFluidData shared library (Python 3)
Ported from Python 2 original.

Changes from Python 2:
- ConfigParser -> configparser
- httplib -> http.client
- print statement -> print()
- os.system echo -> direct file write
- open(path, 'wb') -> open(path, 'w') for config writes
- Exception syntax updated
"""

import configparser
import http.client
import subprocess
import os
import random
import time


def ensure_dir(directory):
    if not os.path.exists(directory):
        os.mkdir(directory)
    elif not os.path.isdir(directory):
        os.remove(directory)
        os.mkdir(directory)


def data_dir():
    return os.path.dirname(__file__) + '/../../data_files'


def cmd_queue_dir():
    return os.path.dirname(__file__) + '/../../cmd_queue'


def open_config_file(path):
    try:
        config = configparser.ConfigParser()
        with open(path) as f:
            config.read_file(f)
        return config
    except IOError:
        log("Config file '{0}' does not exist! Gateway needs to be configured.".format(path))
        return False


def get_gateway_config_file_path():
    return os.path.dirname(__file__) + '/../../gateway.conf'


def open_gateway_config_file():
    return open_config_file(get_gateway_config_file_path())


def open_mfd_config_file():
    return open_config_file(os.path.dirname(__file__) + '/../../conf/myfluiddata.conf')


def random_delay():
    """Random sleep so all gateways don't hit the server at the same time."""
    sleep_duration = random.randint(0, 40)
    log("Delaying for " + str(sleep_duration) + " seconds")
    time.sleep(sleep_duration)


def gateway_post_data(conf):
    return "gateway_hash={0}&location_hash={1}".format(
        conf.get('Gateway', 'gateway_hash'),
        conf.get('Gateway', 'location_hash')
    )


def _make_http():
    """Return HTTP or HTTPS connection based on myfluiddata.conf."""
    conf = open_mfd_config_file()
    domain = conf.get('MyFluidData', 'domain')
    use_ssl = conf.get('MyFluidData', 'use_ssl')
    if use_ssl == 'yes':
        return http.client.HTTPSConnection(domain, timeout=30)
    return http.client.HTTPConnection(domain, timeout=30)


def http_post(url, data=''):
    headers = {
        "Content-type": "application/x-www-form-urlencoded",
        "Accept": "*/*"
    }
    conn = _make_http()
    conn.request("POST", '/' + url, data, headers)
    return conn


def http_get(url, data=''):
    headers = {"Accept": "*/*"}
    conn = _make_http()
    conn.request("GET", '/' + url, data, headers)
    return conn


def log(message, scope='DEBUG'):
    """Log to stdout and append to logs/mfd.log — no shell spawning."""
    message = '{0}: {1}: {2}'.format(str(time.ctime()), scope, message)
    print(message, flush=True)
    log_path = os.path.dirname(__file__) + '/../../logs/mfd.log'
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    try:
        with open(log_path, 'a') as f:
            f.write(message + '\n')
    except Exception as e:
        print(f"Warning: Could not write to log: {e}", flush=True)


def serial_port():
    cmd = 'ls /dev | grep -q "ttyO0" && echo "/dev/ttyO0" || echo "/dev/ttyUSB0"'
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    (port, err) = process.communicate()
    port = port.decode('utf-8').replace("\n", "")
    return port


def get_vpn_ip():
    """Return Tailscale/VPN IP if available, empty string otherwise."""
    # Try Tailscale IP first (100.x.x.x range)
    cmd = "ip addr show | grep -o '100\\.[0-9]*\\.[0-9]*\\.[0-9]*' | head -1"
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    (ip, err) = process.communicate()
    ip = ip.decode('utf-8').strip()
    if ip:
        return ip

    # Fall back to old OpenVPN range (172.x.x.x)
    cmd = "ip addr show | grep -o '172\\.[0-9]*\\.[0-9]*\\.[0-9]*' | head -1"
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    (ip, err) = process.communicate()
    return ip.decode('utf-8').strip()


def baud_rate(rate=False):
    """Get or set the baud rate in gateway.conf."""
    if rate:
        config = open_gateway_config_file()
        config.set('Gateway', 'baud_rate', str(rate))
        with open(get_gateway_config_file_path(), 'w') as config_file:
            config.write(config_file)
        return rate

    rate = get_gateway_config('Gateway', 'baud_rate')
    if not rate:
        rate = 9600
    return rate


def get_gateway_config(section, option):
    config = open_gateway_config_file()
    if config and config.has_option(section, option):
        return config.get(section, option)
    return False
