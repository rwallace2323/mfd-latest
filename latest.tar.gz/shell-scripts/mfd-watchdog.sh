#!/bin/bash
# mfd-watchdog.sh — MFD Gateway hardware watchdog keeper + serial port monitor
# Run as a systemd service. Pets /dev/watchdog every 20 seconds.
# Also monitors ttyS0 health and resets it if RTS/UART state goes bad.
# If this script dies, the hardware watchdog fires and reboots the device.

WATCHDOG_DEV="/dev/watchdog"
SERIAL_PORT="/dev/ttyS0"
SERIAL_BAUD=2400
LOG_FILE="/root/logs/health.log"
SERIAL_FAIL_FILE="/tmp/mfd_serial_failures"
MAX_SERIAL_FAILS=3

mkdir -p /root/logs

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') WATCHDOG: $1" >> "$LOG_FILE"
    echo "$(date '+%Y-%m-%d %H:%M:%S') WATCHDOG: $1"
}

# Open watchdog — writing to it keeps it alive
# Writing V to it disarms it cleanly on exit
exec 200>"$WATCHDOG_DEV" 2>/dev/null || {
    log "WARNING: Could not open $WATCHDOG_DEV — hardware watchdog not available"
}

pet_watchdog() {
    if [ -w "$WATCHDOG_DEV" ]; then
        echo -n "1" >&200 2>/dev/null || true
    fi
}

check_serial_port() {
    # Check for bad RTS/UART state in dmesg
    if dmesg | tail -50 | grep -q "invalid RTS setting"; then
        prev=$(cat "$SERIAL_FAIL_FILE" 2>/dev/null || echo 0)
        fails=$((prev + 1))
        echo "$fails" > "$SERIAL_FAIL_FILE"
        log "Bad RTS state detected on $SERIAL_PORT (count: $fails) — resetting port"
        stty -F "$SERIAL_PORT" "$SERIAL_BAUD" cs8 -cstopb -parenb -crtscts 2>/dev/null
        # Clear the dmesg ring so we don't keep detecting the same message
        dmesg -c > /dev/null 2>&1 || true

        if [ "$fails" -ge "$MAX_SERIAL_FAILS" ]; then
            log "Serial port reset failed $fails times — rebooting"
            echo 0 > "$SERIAL_FAIL_FILE"
            # Disarm watchdog cleanly before reboot
            echo -n "V" >&200 2>/dev/null || true
            reboot
        fi
    else
        # Serial port looks healthy — reset failure counter
        echo "0" > "$SERIAL_FAIL_FILE"
    fi
}

log "Started — petting $WATCHDOG_DEV every 20s, monitoring $SERIAL_PORT"

while true; do
    pet_watchdog
    check_serial_port
    sleep 20
done
