#!/bin/bash
# health_check.sh — MyFluidData gateway health monitor
# Runs as mfd-health.service (systemd restarts it every 15 minutes)
# Reboots the device if any critical health check fails.
# Serial port monitoring is handled by mfd-watchdog.service.

ROOT_DIR="/root"
LOG_FILE="$ROOT_DIR/logs/health.log"
HEARTBEAT_FILE="/tmp/last_checkin_timestamp"
CHECKIN_MAX_AGE=1800   # 30 minutes in seconds
MIN_FREE_MB=20
MAX_DISK_PCT=90
MAX_PYTHON_PROCS=10
PING_HOST="8.8.8.8"
PING_FAIL_FILE="/tmp/mfd_ping_failures"

mkdir -p "$ROOT_DIR/logs"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') HEALTH: $1" >> "$LOG_FILE"
}

do_reboot() {
    log "REBOOTING: $1"
    sleep 2
    reboot
}

# ── Check 1: Python process count ────────────────────────────────────────────
py_count=$(pgrep -c python3 2>/dev/null || echo 0)
if [ "$py_count" -gt "$MAX_PYTHON_PROCS" ]; then
    do_reboot "Too many Python processes: $py_count"
fi

# ── Check 2: Free memory ─────────────────────────────────────────────────────
free_mb=$(free -m | awk '/^Mem:/ {print $4}')
if [ -n "$free_mb" ] && [ "$free_mb" -lt "$MIN_FREE_MB" ]; then
    do_reboot "Low memory: ${free_mb}MB free"
fi

# ── Check 3: Disk usage ───────────────────────────────────────────────────────
disk_pct=$(df / | awk 'NR==2 {gsub(/%/,""); print $5}')
if [ -n "$disk_pct" ] && [ "$disk_pct" -gt "$MAX_DISK_PCT" ]; then
    log "Disk usage ${disk_pct}% — attempting log cleanup"
    find "$ROOT_DIR/logs" -name "*.log" -mtime +3 -delete 2>/dev/null
    find "$ROOT_DIR/data_files" -name "*.dat" -mtime +7 -delete 2>/dev/null
    disk_pct=$(df / | awk 'NR==2 {gsub(/%/,""); print $5}')
    if [ "$disk_pct" -gt "$MAX_DISK_PCT" ]; then
        do_reboot "Disk still critical after cleanup: ${disk_pct}%"
    fi
fi

# ── Check 4: Internet connectivity ───────────────────────────────────────────
if ping -c 1 -W 5 "$PING_HOST" > /dev/null 2>&1; then
    echo "0" > "$PING_FAIL_FILE"
else
    prev=$(cat "$PING_FAIL_FILE" 2>/dev/null || echo 0)
    fails=$((prev + 1))
    echo "$fails" > "$PING_FAIL_FILE"
    log "Ping failed ($fails consecutive)"

    if [ "$fails" -eq 2 ]; then
        log "Attempting interface restart"
        iface=$(ip route | awk '/default/ {print $5; exit}')
        if [ -n "$iface" ]; then
            ip link set "$iface" down
            sleep 3
            ip link set "$iface" up
        fi
    elif [ "$fails" -ge 3 ]; then
        do_reboot "No internet after $fails consecutive failures"
    fi
fi

# ── Check 5: Check-in heartbeat ──────────────────────────────────────────────
if [ -f "$HEARTBEAT_FILE" ]; then
    last_ts=$(cat "$HEARTBEAT_FILE")
    now_ts=$(date +%s)
    age=$((now_ts - last_ts))
    if [ "$age" -gt "$CHECKIN_MAX_AGE" ]; then
        do_reboot "No check-in for ${age}s (max ${CHECKIN_MAX_AGE}s)"
    fi
fi

# ── Check 6: Core services running ───────────────────────────────────────────
for svc in mfd-checkin mfd-executor mfd-negotiate mfd-watchdog; do
    if ! systemctl is-active --quiet "$svc"; then
        log "Service $svc is not running — restarting"
        systemctl restart "$svc" 2>/dev/null || log "Failed to restart $svc"
    fi
done

log "Health check passed (py=$py_count mem=${free_mb}MB disk=${disk_pct}%)"
