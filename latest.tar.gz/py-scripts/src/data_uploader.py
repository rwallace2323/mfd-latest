#!/usr/bin/env python3
"""
data_uploader.py — MyFluidData data uploader (Python 3)
Ported from Python 2 original with freeze fixes applied.

FREEZE FIXES:
- Process lock via fcntl — prevents duplicate cron instances
- Fixed: `if file_chunks == 0` -> `if len(file_chunks) == 0`
  (original compared list to int, always False — "No data" never triggered)
- urllib.quote() -> urllib.parse.quote()
- xrange() -> range()
- File reads wrapped in try/except — one bad file won't kill the whole run
- HTTP connection has timeout (via mfd._make_http())
"""

import fcntl
import os
import sys
import urllib.parse
import mfd

log_scope = 'UPLOADER'

# ── Process lock ──────────────────────────────────────────────────────────────
_lock_fp = open('/tmp/uploader.lock', 'w')
try:
    fcntl.lockf(_lock_fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
except IOError:
    mfd.log("data_uploader.py already running — exiting", log_scope)
    sys.exit(0)


def chunk_files(l, n):
    """Yield successive n-sized chunks from l."""
    for i in range(0, len(l), n):
        yield l[i:i + n]


def send_data(files):
    config = mfd.open_gateway_config_file()
    gateway_hash = config.get('Gateway', 'gateway_hash')
    post_data = "gateway_hash=" + gateway_hash + "&"

    mfd.log("Uploading {0} files for Gateway({1})".format(len(files), gateway_hash), log_scope)

    for filename in files:
        try:
            with open(mfd.data_dir() + "/" + filename, "r") as fp:
                file_contents = fp.read()
            # urllib.quote() -> urllib.parse.quote()
            post_data += "&results[]=" + urllib.parse.quote(file_contents)
            post_data += "&files[]=" + urllib.parse.quote(filename)
        except Exception as e:
            mfd.log("Could not read file {0}: {1}".format(filename, str(e)), log_scope)
            continue

    try:
        conn = mfd.http_post('incoming_data.json', post_data)
        res = conn.getresponse()

        if res.status == 200:
            for filename in files:
                try:
                    os.unlink(mfd.data_dir() + "/" + filename)
                except Exception as e:
                    mfd.log("Could not remove {0}: {1}".format(filename, str(e)), log_scope)
        else:
            mfd.log('{0} {1}'.format(res.status, res.reason), log_scope)
            mfd.log(res.read().decode('utf-8', errors='replace'), log_scope)

        conn.close()

    except Exception as e:
        mfd.log("Upload HTTP error: " + str(e), log_scope)


# ── Main ──────────────────────────────────────────────────────────────────────

mfd.log("------------------------------------------------", log_scope)
mfd.log("- Uploading Data", log_scope)
mfd.log("------------------------------------------------", log_scope)

mfd.random_delay()

mfd.ensure_dir(mfd.data_dir())
file_list = sorted(os.listdir(mfd.data_dir()))
file_chunks = list(chunk_files(file_list, 5))

# Fixed: was `if file_chunks == 0` — compared list to int, always False
if len(file_chunks) == 0:
    mfd.log("No data to post", log_scope)
else:
    for files in file_chunks:
        send_data(files)

mfd.log("------------------------------------------------", log_scope)
mfd.log("- Finished Uploading Data", log_scope)
mfd.log("------------------------------------------------", log_scope)
