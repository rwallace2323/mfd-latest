#!/usr/bin/env python3
"""
send_debug.py — MyFluidData debug info uploader (Python 3)
Ported from Python 2 original.

Changes from Python 2:
- urllib.quote() -> urllib.parse.quote()
- res.read() -> res.read().decode('utf-8')
- open() with explicit encoding
"""

import urllib.parse
import os
import sys
import mfd

log_scope = 'DEBUG INFO'

mfd.random_delay()

config = mfd.open_gateway_config_file()
if not config:
    mfd.log("No gateway config found", log_scope)
    sys.exit(1)

gateway_hash = config.get('Gateway', 'gateway_hash')

debug_file = os.path.join(os.path.dirname(__file__), '..', '..', 'debug.info')

if not os.path.exists(debug_file):
    mfd.log("debug.info not found — skipping", log_scope)
    sys.exit(0)

mfd.log("Uploading debug.info", log_scope)

try:
    with open(debug_file, 'r', encoding='utf-8', errors='replace') as fp:
        file_contents = fp.read()
except Exception as e:
    mfd.log("Could not read debug.info: " + str(e), log_scope)
    sys.exit(1)

# Fixed: urllib.quote() -> urllib.parse.quote()
post_data = "gateway_hash=" + gateway_hash + "&content=" + urllib.parse.quote(file_contents)

try:
    conn = mfd.http_post('gateways/debug_info.json', post_data)
    res = conn.getresponse()

    if res.status == 200:
        mfd.log('debug.info sent', log_scope)
    else:
        mfd.log('{0} {1}'.format(res.status, res.reason), log_scope)
        mfd.log(res.read().decode('utf-8', errors='replace'), log_scope)

    conn.close()

except Exception as e:
    mfd.log("HTTP error sending debug.info: " + str(e), log_scope)
