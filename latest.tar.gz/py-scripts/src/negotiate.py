#!/usr/bin/env python3
"""
negotiate.py — MyFluidData gauge negotiation (Python 3)
Ported from Python 2 original with freeze fixes applied.

FREEZE FIXES:
- Exits immediately if gauge_model already configured in gateway.conf
  (original ran every 5 min fighting executor for serial port)
- chr(ascii.SOH) -> bytes([ascii.SOH]) — Python 3 serial.write() requires bytes
- String comparison line[1:7] == vr_cmd -> bytes comparison line[1:7] == vr_cmd.encode()
- open(path, 'wb') -> open(path, 'w') for config writes
- Serial port closed after each attempt to avoid port lock
- All serial attempts wrapped in try/except
"""

from curses import ascii
import os
import sys
import serial
import mfd

log_scope = 'NEGOTIATE'

# ── Exit immediately if already configured ────────────────────────────────────
# FREEZE FIX: original ran every 5 min fighting executor for serial port.
config = mfd.open_gateway_config_file()
if config and config.has_option('Gateway', 'gauge_model') and config.get('Gateway', 'gauge_model'):
    gauge_model = config.get('Gateway', 'gauge_model')
    mfd.log("Gauge already configured ({0}) — reinstalling crontab".format(gauge_model), log_scope)
    if gauge_model == 'Veeder-Root':
        os.system('cd ~ && cat cron/base.cron cron/negotiate.cron cron/veeder-root.cron | crontab -')
    elif gauge_model == 'Auto-Stik':
        os.system('cd ~ && cat cron/base.cron cron/negotiate.cron cron/auto-stik.cron | crontab -')
    sys.exit(0)

mfd.log("------------------------------------------------", log_scope)
mfd.log("- Negotiating with Fuel Gauge", log_scope)
mfd.log("------------------------------------------------", log_scope)

found = False

# ── Try Veeder-Root first at 9600 ─────────────────────────────────────────────
try:
    ser = serial.Serial(mfd.serial_port(), 9600, timeout=5)
    vr_cmd = 'i90200'
    # Fixed: chr(ascii.SOH) + str -> bytes for Python 3
    ser.write(bytes([ascii.SOH]) + vr_cmd.encode('ascii'))
    line = ser.readline(1000)
    ser.close()

    # Fixed: string comparison -> bytes comparison
    if line[1:7] == vr_cmd.encode('ascii'):
        mfd.log("Fuel Gauge is Veeder-Root", log_scope)
        mfd.log("Installing Veeder-Root cron jobs", log_scope)
        os.system('cat cron/base.cron cron/veeder-root.cron | crontab -')
        mfd.baud_rate(9600)

        config = mfd.open_gateway_config_file()
        config.set('Gateway', 'gauge_model', 'Veeder-Root')
        # Fixed: 'wb' -> 'w' for Python 3
        with open(mfd.get_gateway_config_file_path(), 'w') as config_file:
            config.write(config_file)
        found = True

except Exception as e:
    mfd.log("Veeder-Root probe error: " + str(e), log_scope)

# ── Try Auto-Stik if Veeder-Root not found ────────────────────────────────────
if not found:
    mfd.log("Try an Auto-Stik Command", log_scope)
    baud_rates = [2400, 9600, 110, 150, 300, 600, 4800]
    the_baud_rate = 0

    for rate in baud_rates:
        try:
            ser = serial.Serial(mfd.serial_port(), rate, timeout=5)
            ser.write(bytes([ascii.SOH]) + b'100')
            line = ser.readline(1000)
            ser.close()

            # Fixed: line[1:2] != '' -> line[1:2] != b''
            if line[1:2] != b'':
                mfd.log("Fuel Gauge is Auto-Stik", log_scope)
                the_baud_rate = rate
                mfd.baud_rate(rate)
                found = True
                break

        except Exception as e:
            mfd.log("Auto-Stik probe error at {0}: {1}".format(rate, str(e)), log_scope)

    if not found or the_baud_rate == 0:
        mfd.log("No gauge found — will retry on next cron cycle", log_scope)
    else:
        mfd.log("Fuel Gauge is Auto-Stik", log_scope)
        mfd.log("Baud Rate is {0}".format(the_baud_rate), log_scope)
        mfd.log("Installing Auto-Stik cron jobs", log_scope)
        os.system('cat cron/base.cron cron/auto-stik.cron | crontab -')

        config = mfd.open_gateway_config_file()
        config.set('Gateway', 'gauge_model', 'Auto-Stik')
        with open(mfd.get_gateway_config_file_path(), 'w') as config_file:
            config.write(config_file)

mfd.log("------------------------------------------------", log_scope)
mfd.log("- End Negotiating with Fuel Gauge", log_scope)
mfd.log("------------------------------------------------", log_scope)
