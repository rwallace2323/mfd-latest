#!/bin/bash
# /etc/profile.d/mfd-motd.sh
# Displayed at every SSH login

CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
RED='\033[1;31m'
NC='\033[0m'
BOLD='\033[1m'

VERSION=$(cat /root/version.txt 2>/dev/null || echo "unknown")
HOSTNAME=$(hostname)
UPTIME=$(uptime -p 2>/dev/null | sed 's/up //')
IP_ETH=$(ip -4 addr show eth0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
IP_ZT=$(ip -4 addr show 2>/dev/null | grep -A1 "zt" | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
IP_TS=$(ip -4 addr show tailscale0 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
GAUGE=$(grep "^gauge_model" /root/gateway.conf 2>/dev/null | cut -d= -f2 | tr -d ' ')
LAST_DATA=$(ls -t /root/data_files/*.dat 2>/dev/null | head -1 | xargs ls -lh 2>/dev/null | awk '{print $6, $7, $8}')
CRON_COUNT=$(crontab -l 2>/dev/null | grep -v "^#" | grep -v "^$" | wc -l)
SERIAL=$(systemctl is-active serial-getty@ttyS0.service 2>/dev/null)

echo ""
echo -e "${CYAN}${BOLD}  ╔══════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}${BOLD}  ║         MFD Gateway -- $(printf '%-20s' $HOSTNAME)  ║${NC}"
echo -e "${CYAN}${BOLD}  ╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${WHITE}  Gateway Files : ${GREEN}${VERSION}${NC}"
echo -e "${WHITE}  Uptime        : ${NC}${UPTIME}"
echo ""
echo -e "${WHITE}  Network${NC}"
echo -e "${WHITE}    eth0        : ${NC}${IP_ETH:-not connected}"
echo -e "${WHITE}    ZeroTier    : ${NC}${IP_ZT:-not connected}"
echo -e "${WHITE}    Tailscale   : ${NC}${IP_TS:-not connected}"
echo ""
echo -e "${WHITE}  Gateway${NC}"
if [[ -n "$GAUGE" ]]; then
  echo -e "${WHITE}    Gauge Model : ${GREEN}${GAUGE}${NC}"
else
  echo -e "${WHITE}    Gauge Model : ${YELLOW}not detected yet${NC}"
fi
echo -e "${WHITE}    Cron Jobs   : ${NC}${CRON_COUNT} active"
if [[ -n "$LAST_DATA" ]]; then
  echo -e "${WHITE}    Last Data   : ${NC}${LAST_DATA}"
else
  echo -e "${WHITE}    Last Data   : ${YELLOW}no data files yet${NC}"
fi
echo ""

# Serial port warning if not masked
if [[ "$SERIAL" != "masked" ]]; then
  echo -e "${RED}  WARNING: serial-getty@ttyS0 is not masked (status: $SERIAL)${NC}"
  echo -e "${RED}           Run: systemctl mask serial-getty@ttyS0.service${NC}"
  echo ""
fi

echo -e "${WHITE}  Staging       : staging.myfluiddata.com${NC}"
echo -e "${WHITE}  Log           : /var/log/mfd-deploy.log${NC}"
echo ""
