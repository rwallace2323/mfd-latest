#!/usr/bin/env python3
# atg-test.sh — MFD Gateway ATG field diagnostic tool
# Usage: ./atg-test.sh [command]
#        ./atg-test.sh 100          # inventory
#        ./atg-test.sh 150          # deliveries
#        ./atg-test.sh i20100       # Veeder-Root inventory
#        ./atg-test.sh              # uses default command for detected gauge
#
# Reads gauge type, serial port, and baud rate from gateway.conf automatically.
# Uses pyserial directly — no kermit, no port state corruption risk.
# Safe to run while gateway scripts are running — uses a short exclusive lock.

import sys
import os
import time
import configparser
import fcntl
import termios

# ── Config ────────────────────────────────────────────────────────────────────
GATEWAY_CONF   = '/root/gateway.conf'
MFD_CONF       = '/root/conf/myfluiddata.conf'
LOCK_FILE      = '/tmp/atg_test.lock'
DEFAULT_PORT   = '/dev/ttyS0'
DEFAULT_BAUD   = 2400
RESPONSE_TIMEOUT = 15  # seconds to wait for ATG response

# Default test commands per gauge type
DEFAULT_COMMANDS = {
    'Auto-Stik':   '100',
    'Veeder-Root': 'i20100',
}

# Command descriptions
COMMAND_DESCRIPTIONS = {
    # Auto-Stik
    '100':  'Inventory (tank levels)',
    '140':  'Alarm status',
    '150':  'Delivery report',
    '1A0':  'Alarm status (alternate)',
    # Veeder-Root
    'i20100': 'Inventory (volume, height, water, temp)',
    'i20200': 'Delivery report',
    'i20700': 'Leak test history',
    'i21200': 'Leak test history 2',
    'i25100': 'Reconciliation report',
    'i30100': 'Sensor report',
    'i60100': 'Tank configuration',
    'i60200': 'Product labels',
    'i60400': 'Tank full volume',
    'i90200': 'System firmware/revision',
    # Uppercase human-readable VR variants
    'I25100': 'Reconciliation report (human readable)',
    'I30100': 'Sensor report (human readable)',
}

# ── Colors ────────────────────────────────────────────────────────────────────
class C:
    CYAN   = '\033[1;36m'
    GREEN  = '\033[1;32m'
    YELLOW = '\033[1;33m'
    RED    = '\033[1;31m'
    WHITE  = '\033[1;37m'
    BOLD   = '\033[1m'
    NC     = '\033[0m'

def banner():
    print(f"\n{C.CYAN}{C.BOLD}  MFD Gateway — ATG Field Test{C.NC}")
    print(f"{C.WHITE}  Direct serial diagnostic — safe to use on live gateway{C.NC}\n")

def ok(msg):    print(f"{C.GREEN}  OK    {msg}{C.NC}")
def warn(msg):  print(f"{C.YELLOW}  WARN  {msg}{C.NC}")
def err(msg):   print(f"{C.RED}  ERROR {msg}{C.NC}")
def info(msg):  print(f"{C.WHITE}  {msg}{C.NC}")

# ── Read gateway config ───────────────────────────────────────────────────────
def read_config():
    config = configparser.ConfigParser()
    gauge_model = None
    serial_port = DEFAULT_PORT
    baud_rate   = DEFAULT_BAUD

    if os.path.exists(GATEWAY_CONF):
        config.read(GATEWAY_CONF)
        try:
            gauge_model = config.get('Gateway', 'gauge_model')
        except (configparser.NoSectionError, configparser.NoOptionError):
            pass
        try:
            baud_rate = int(config.get('Gateway', 'baud_rate'))
        except (configparser.NoSectionError, configparser.NoOptionError, ValueError):
            pass
        try:
            serial_port = config.get('Serial Port', 'port')
        except (configparser.NoSectionError, configparser.NoOptionError):
            pass
    return gauge_model, serial_port, baud_rate

# ── Send command and get response ─────────────────────────────────────────────
def send_command(port, baud, command, gauge_model):
    try:
        import serial
    except ImportError:
        err("python3-serial not installed. Run: apt-get install python3-serial")
        sys.exit(1)

    # Build the command bytes
    # Auto-Stik: SOH + command (e.g. b'\x01100')
    # Veeder-Root: SOH + command (e.g. b'\x01i20100')
    cmd_bytes = bytes([0x01]) + command.encode('ascii')

    print(f"\n{C.CYAN}{'─'*50}{C.NC}")
    info(f"Port     : {port}")
    info(f"Baud     : {baud}")
    info(f"Gauge    : {gauge_model or 'Unknown'}")
    info(f"Command  : {command}  ({COMMAND_DESCRIPTIONS.get(command, 'custom command')})")
    info(f"Sending  : SOH + '{command}'")
    print(f"{C.CYAN}{'─'*50}{C.NC}\n")

    try:
        ser = serial.Serial(
            port=port,
            baudrate=baud,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            xonxoff=True,        # software flow control — matches kermit config
            rtscts=False,        # no hardware flow control
            timeout=1
        )
    except serial.SerialException as e:
        err(f"Could not open {port}: {e}")
        err("Is another process using the port? Check: fuser /dev/ttyS0")
        sys.exit(1)

    try:
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        ser.write(cmd_bytes)
        ser.flush()

        info("Command sent — waiting for response...")
        response = b''
        start = time.time()
        last_data = time.time()

        while time.time() - start < RESPONSE_TIMEOUT:
            chunk = ser.read(256)
            if chunk:
                response += chunk
                last_data = time.time()
                # ATG responses end with ETX (0x03) for VR or have natural end
                if b'\x03' in chunk:
                    break
            else:
                # If we have data and nothing came in for 1 second, we're done
                if response and (time.time() - last_data > 1.0):
                    break

        ser.close()

        if not response:
            err(f"No response received after {RESPONSE_TIMEOUT}s")
            err("Check: cable connected? ATG powered on? Correct baud rate?")
            return None

        return response

    except serial.SerialException as e:
        ser.close()
        err(f"Serial error: {e}")
        return None

# ── Display response ──────────────────────────────────────────────────────────
def display_response(response, command, gauge_model):
    print(f"{C.GREEN}{C.BOLD}  Response received ({len(response)} bytes):{C.NC}\n")

    # Try to decode as ASCII/latin-1 for display
    try:
        text = response.decode('latin-1')
    except Exception:
        text = repr(response)

    # Print raw response
    print(f"{C.WHITE}  Raw:{C.NC}")
    print(f"  {repr(text)}\n")

    # Print printable version
    printable = ''.join(c if (32 <= ord(c) < 127) else '?' for c in text)
    print(f"{C.WHITE}  Readable:{C.NC}")
    print(f"  {printable}\n")

    # Save to a temp file for reference
    ts = int(time.time())
    outfile = f"/tmp/atg_test_{ts}_{command}.dat"
    with open(outfile, 'wb') as f:
        f.write(response)
    ok(f"Response saved to {outfile}")

# ── Show available commands ───────────────────────────────────────────────────
def show_commands(gauge_model):
    print(f"\n{C.CYAN}{C.BOLD}  Available commands for {gauge_model}:{C.NC}\n")
    if gauge_model == 'Auto-Stik':
        cmds = ['100', '140', '150', '1A0']
    elif gauge_model == 'Veeder-Root':
        cmds = ['i20100','i20200','i20700','i21200','i25100','I25100','i30100','I30100','i60100','i60200','i60400','i90200']
    else:
        cmds = list(COMMAND_DESCRIPTIONS.keys())

    for cmd in cmds:
        desc = COMMAND_DESCRIPTIONS.get(cmd, '')
        print(f"  {C.WHITE}./atg-test.sh {cmd:<12}{C.NC}  {desc}")
    print()

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    banner()

    # Process lock — prevent two simultaneous tests
    lock_fp = open(LOCK_FILE, 'w')
    try:
        fcntl.lockf(lock_fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError:
        err("Another atg-test.sh is already running — exiting")
        sys.exit(1)

    gauge_model, serial_port, baud_rate = read_config()

    if not gauge_model:
        warn("No gauge_model found in gateway.conf")
        warn("Run negotiate.py first, or specify command manually")
        gauge_model = 'Unknown'

    # Determine command
    if len(sys.argv) > 1:
        command = sys.argv[1]
        if command in ('-h', '--help', 'help'):
            show_commands(gauge_model)
            sys.exit(0)
    else:
        command = DEFAULT_COMMANDS.get(gauge_model)
        if not command:
            err(f"No default command for gauge type '{gauge_model}'")
            show_commands(gauge_model)
            sys.exit(1)
        info(f"No command specified — using default for {gauge_model}: {command}")

    # Send and display
    response = send_command(serial_port, baud_rate, command, gauge_model)
    if response:
        display_response(response, command, gauge_model)
        print(f"{C.GREEN}{C.BOLD}  Test complete.{C.NC}\n")
    else:
        print(f"{C.RED}{C.BOLD}  Test failed — no response from ATG.{C.NC}\n")
        sys.exit(1)

if __name__ == '__main__':
    main()
